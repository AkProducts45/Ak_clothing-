AK CLOTHING WEBSITE

Files:
- index.html: complete responsive storefront.

Publish with GitHub Pages:
1. Open your GitHub repository: https://github.com/Alikhan843/ak-clothing
2. Open the repository and upload/replace index.html.
3. Commit the change.
4. In Settings > Pages, select Deploy from a branch, branch main, folder /(root), then Save.
5. Your existing site link is https://Akproducts45.github.io/Ak_clothing-/

Important:
- Product prices are set to 0 (shown as "Price on request") because exact prices were not supplied.
- Product cards currently use built-in placeholder shirt artwork. Replace these with your real product photos before launch.
- WhatsApp contact is set to 0308 6625610.
- Edit product names/prices in the `products` array near the bottom of index.html.
